from AutoCADlib import AutoCAD

cad = AutoCAD()